package recursion;
/**
 * this class creates the methods of 
 * calculating the sum of array
 * @author hunegnaw
 *
 */

public class ArraySum {
	
	/**
	 * create a method called sumOfAraay
	 * @param a
	 * @param index
	 * @return
	 */
public int sumOfArray(Integer[] a,int index)
{
	//validate the index
	if(index<=0) {
		return 0;
	}
	else
	{
		return sumOfArray(a,index-1)+a[index-1];
	}
	}
}
