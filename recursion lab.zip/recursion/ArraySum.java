package recursion;
/**
 * this class creates the methods of 
 * calculating the sum of array
 * @author hunegnaw
 *
 */

public class ArraySum {
	
	/**
	 * create a method called sumOfAraay
	 * @param a
	 * @param index
	 * @return
	 */
public int sumOfArray(Integer[] a,int index)
{
	//validate the index
	if(a[index]==0) {
		return 0;
	}
	else if(index==0)
	{
		return a[index];
	}
	else
	{
		Integer sumOfReset=sumOfArray(a,index-1);
		return a[index]+sumOfReset;
		
	}
	}
}
